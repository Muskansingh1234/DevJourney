package com.example.Myfirstproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyfirstprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
